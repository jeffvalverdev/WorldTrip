package worldTrip.controlador;

import java.util.ArrayList;
import java.util.List;
import worldTrip.modelo.Tour;

public class ControladorListaTours {

    private List<Tour> listaTours;

    public ControladorListaTours() {
        listaTours = new ArrayList<>();
    }

    public void agregarTour(Tour tour) {
        listaTours.add(tour);
    }

    public boolean eliminarTour(int codigoTour) {
        for (Tour tour : listaTours) {
            if (tour.getCodigoTour() == codigoTour) {
                listaTours.remove(tour);
                return true;
            }
        }
        return false;
    }

    public boolean actualizarTour(Tour tourActualizado) {
        for (int i = 0; i < listaTours.size(); i++) {
            if (listaTours.get(i).getCodigoTour() == tourActualizado.getCodigoTour()) {
                listaTours.set(i, tourActualizado);
                return true;
            }
        }
        return false;
    }

    public Tour obtenerTour(int codigoTour) {
        for (Tour tour : listaTours) {
            if (tour.getCodigoTour() == codigoTour) {
                return tour;
            }
        }
        return null;
    }

    public List<Tour> obtenerTodosLosTours() {
        return new ArrayList<>(listaTours);
    }

    public int contarTours() {
        return listaTours.size();
    }

    public static void main(String[] args) {
        // Ejemplo de uso del controlador
    	ControladorListaTours controlador = new ControladorListaTours();

        Tour tour1 = new Tour(1, "Tour por Gran vía", 10, 70, "2024-06-01", "2024-06-10");
        Tour tour2 = new Tour(2, "Tour por Retiro", 15, 70, "2024-07-01", "2024-07-15");

        
        
        controlador.agregarTour(tour1);
        controlador.agregarTour(tour2);

        System.out.println("Todos los tours: " + controlador.obtenerTodosLosTours());
        System.out.println("Contar tours: " + controlador.contarTours());

        Tour tourActualizado = new Tour(1, "Tour por Gran Vía", 12, 1600.0, "2024-06-01", "2024-06-12");
        controlador.actualizarTour(tourActualizado);
        
        System.out.println("Tour actualizado: " + controlador.obtenerTour(1));

        controlador.eliminarTour(2);
        System.out.println("Todos los tours después de eliminar: " + controlador.obtenerTodosLosTours());
    }
}

