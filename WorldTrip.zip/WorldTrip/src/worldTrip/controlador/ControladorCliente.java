package worldTrip.controlador;

import worldTrip.modelo.Agencia;
import worldTrip.modelo.Cliente;
import worldTrip.modelo.Reserva;
import worldTrip.modelo.Tour;

public class ControladorCliente {
    private Agencia sistema;

    public ControladorCliente(Agencia sistema) {
        this.sistema = sistema;
    }

    public Cliente crearCliente(String nombre, String apellido, String email, String telefono) {
        Cliente cliente = new Cliente(nombre, apellido, email, telefono);
        // Aquí agregarías el código para guardar el cliente en la base de datos o en tu estructura de almacenamiento
        return cliente;
    }

    public Cliente buscarCliente(int codigo, String email) {
        Cliente cliente = sistema.buscarCliente(codigo);
        if (cliente != null && cliente.getEmail().equals(email)) {
            return cliente;
        }
        return null;
    }

    public Reserva obtenerReserva(Cliente cliente) {
        for (Reserva reserva : sistema.obtenerTodasLasReservas()) {
            if (reserva.getCliente().equals(cliente)) {
                return reserva;
            }
        }
        return null;
    }

    public Tour obtenerTour(Reserva reserva) {
        return reserva.getTour(); // Suponiendo que la reserva tiene un método getTour()
    }
}



