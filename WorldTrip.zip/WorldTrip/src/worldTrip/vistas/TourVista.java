package worldTrip.vistas;

import worldTrip.controlador.ControladorListaTours;
import worldTrip.controlador.ControladorReserva;
import worldTrip.modelo.Tour;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TourVista extends JFrame {
    private static final long serialVersionUID = 1L;
    private ControladorListaTours controlador;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField txtCodigoTour;
    private JComboBox<String> cmbNombreTour;
    private JTextField txtDuracion;
    private JTextField txtCoste;
    private JTextField txtFechaInicio;
    private JTextField txtFechaFin;
	protected ControladorReserva controladorReserva;

    public TourVista() {
        controlador = new ControladorListaTours();
        initComponents();
    }

    private void initComponents() {
        setTitle("Gestión de Tours");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BorderLayout());
        panelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        panelPrincipal.setBackground(new Color(240, 240, 240));
        add(panelPrincipal, BorderLayout.CENTER);

        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new GridBagLayout());
        panelFormulario.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Detalles del Tour", TitledBorder.CENTER, TitledBorder.TOP));
        panelFormulario.setBackground(Color.WHITE);
        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panelFormulario.add(new JLabel("Código Tour:"), gbc);
        gbc.gridx = 1;
        txtCodigoTour = new JTextField(20);
        panelFormulario.add(txtCodigoTour, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panelFormulario.add(new JLabel("Nombre Tour:"), gbc);
        gbc.gridx = 1;
        cmbNombreTour = new JComboBox<>(new String[]{
            "Tour por la Ciudad de Madrid",
            "Sitios Históricos de Madrid",
            "Arte y Cultura en Madrid",
            "Experiencia Culinaria en Madrid",
            "Madrid y sus Alrededores",
            "Vida Nocturna en Madrid",
            "Parques y Jardines de Madrid",
            "Tour de Arquitectura en Madrid",
            "Día de Compras en Madrid",
            "Deportes y Actividades en Madrid"
        });
        panelFormulario.add(cmbNombreTour, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panelFormulario.add(new JLabel("Duración:"), gbc);
        gbc.gridx = 1;
        txtDuracion = new JTextField(20);
        panelFormulario.add(txtDuracion, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panelFormulario.add(new JLabel("Coste:"), gbc);
        gbc.gridx = 1;
        txtCoste = new JTextField("70", 20); 
        txtCoste.setEditable(false);
        panelFormulario.add(txtCoste, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panelFormulario.add(new JLabel("Fecha Inicio:"), gbc);
        gbc.gridx = 1;
        txtFechaInicio = new JTextField(20);
        panelFormulario.add(txtFechaInicio, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        panelFormulario.add(new JLabel("Fecha Fin:"), gbc);
        gbc.gridx = 1;
        txtFechaFin = new JTextField(20);
        panelFormulario.add(txtFechaFin, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(Color.WHITE);
        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBackground(new Color(70, 130, 180));
        btnAgregar.setForeground(Color.WHITE);
        btnAgregar.setFocusPainted(false);
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarTour();
            }
        });
        panelBotones.add(btnAgregar);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBackground(new Color(70, 130, 180));
        btnActualizar.setForeground(Color.WHITE);
        btnActualizar.setFocusPainted(false);
        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarTour();
            }
        });
        panelBotones.add(btnActualizar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBackground(new Color(70, 130, 180));
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFocusPainted(false);
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarTour();
            }
        });
        panelBotones.add(btnEliminar);
        
        JButton btnVolver = new JButton("Volver");
        btnVolver.setBackground(new Color(70, 130, 180));
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setFocusPainted(false);
        btnVolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Cerrar la ventana actual de ToursVista
                ReservaVista reservaVista = new ReservaVista(controladorReserva); // Crear una instancia de ReservaVista
                reservaVista.setVisible(true); // Mostrar la ventana ReservaVista
            }
        });
        add(btnVolver, BorderLayout.WEST); // Agregar el botón "Volver" al panel de ToursVista


        panelFormulario.add(panelBotones, gbc);

        tableModel = new DefaultTableModel(new Object[]{"Código", "Nombre", "Duración", "Coste", "Fecha Inicio", "Fecha Fin"}, 0);
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(table);
        panelPrincipal.add(scrollPane, BorderLayout.CENTER);

        JButton btnCargar = new JButton("Cargar Tours");
        btnCargar.setBackground(new Color(70, 130, 180));
        btnCargar.setForeground(Color.WHITE);
        btnCargar.setFocusPainted(false);
        btnCargar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarTours();
            }
        });
        panelPrincipal.add(btnCargar, BorderLayout.SOUTH);
    }

    private void agregarTour() {
        int codigoTour = Integer.parseInt(txtCodigoTour.getText());
        String nombreTour = (String) cmbNombreTour.getSelectedItem();
        int duracion = Integer.parseInt(txtDuracion.getText());
        double coste = 70; // Precio fijo de 70 euros
        String fechaInicio = txtFechaInicio.getText();
        String fechaFin = txtFechaFin.getText();

        Tour tour = new Tour(codigoTour, nombreTour, duracion, coste, fechaInicio, fechaFin);
        controlador.agregarTour(tour);
        cargarTours();
    }

    private void actualizarTour() {
        int codigoTour = Integer.parseInt(txtCodigoTour.getText());
        String nombreTour = (String) cmbNombreTour.getSelectedItem();
        int duracion = Integer.parseInt(txtDuracion.getText());
        double coste = 70; // Precio fijo de 70 euros
        String fechaInicio = txtFechaInicio.getText();
        String fechaFin = txtFechaFin.getText();

        Tour tourActualizado = new Tour(codigoTour, nombreTour, duracion, coste, fechaInicio, fechaFin);
        controlador.actualizarTour(tourActualizado);
        cargarTours();
    }

    private void eliminarTour() {
        int codigoTour = Integer.parseInt(txtCodigoTour.getText());
        controlador.eliminarTour(codigoTour);
        cargarTours();
    }

    private void cargarTours() {
        tableModel.setRowCount(0);
        for (Tour tour : controlador.obtenerTodosLosTours()) {
            tableModel.addRow(new Object[]{tour.getCodigoTour(), tour.getNombreTour(), tour.getDuracion(),
            		tour.getCoste(), tour.getFechaInicio(), tour.getFechaFin()});
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TourVista vista = new TourVista();
                vista.setVisible(true);
                
            }
        });
    }
}




