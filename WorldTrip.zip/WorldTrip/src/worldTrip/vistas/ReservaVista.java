package worldTrip.vistas;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import worldTrip.controlador.ControladorReserva;
import worldTrip.modelo.Cliente;
import worldTrip.modelo.Reserva;
import worldTrip.modelo.Tour;
import worldTrip.modelo.Agencia;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ReservaVista extends JFrame {
    private static final long serialVersionUID = 1L;
    private DefaultTableModel tableModel;
    private JTable table;
    private ControladorReserva controladorReserva;
    private JTextField txtEmail;
    private JTextField txtCodigoCliente;

    public ReservaVista(ControladorReserva controladorReserva) {
        this.controladorReserva = controladorReserva;
        initComponents();
    }

    private void initComponents() {
        setTitle("Gestión de Reservas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BorderLayout());
        panelPrincipal.setBorder(new EmptyBorder(10, 10, 10, 10));
        add(panelPrincipal, BorderLayout.CENTER);

        // Panel de formulario
        JPanel panelFormulario = new JPanel();
        panelFormulario.setLayout(new BorderLayout());
        panelFormulario.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Detalles de la Reserva", TitledBorder.CENTER, TitledBorder.TOP));
        panelPrincipal.add(panelFormulario, BorderLayout.NORTH);

        // Agregar campos para el código de cliente y el email
        JPanel panelCampos = new JPanel(new GridLayout(2, 2, 5, 5));
        panelCampos.setBorder(new EmptyBorder(10, 10, 10, 10));
        panelFormulario.add(panelCampos, BorderLayout.CENTER);

        panelCampos.add(new JLabel("Código Cliente:"));
        txtCodigoCliente = new JTextField(20);
        panelCampos.add(txtCodigoCliente);

        panelCampos.add(new JLabel("Email:"));
        txtEmail = new JTextField(20);
        panelCampos.add(txtEmail);

        // Tabla para mostrar las reservas
        tableModel = new DefaultTableModel(new Object[]{"Código Reserva", "Hotel", "Número de Personas", "Fecha Inicio", "Fecha Fin", "Coste Total", "Dirección", "Código Cliente", "Email"}, 0);
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(table);
        panelPrincipal.add(scrollPane, BorderLayout.CENTER);

        // Botón para cargar reservas
        JButton btnCargar = new JButton("Cargar Reservas");
        btnCargar.setBackground(new Color(70, 130, 180));
        btnCargar.setForeground(Color.WHITE);
        btnCargar.setFocusPainted(false);
        btnCargar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarReservas();
            }
        });
        panelPrincipal.add(btnCargar, BorderLayout.SOUTH);
        
        // Botones para modificar y eliminar reservas
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelBotones.setBorder(new EmptyBorder(10, 0, 0, 0));
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
        
        JButton btnAgregar = new JButton("Agregar Reserva");
        btnAgregar.setBackground(new Color(70, 130, 180));
        btnAgregar.setForeground(Color.WHITE);
        btnAgregar.setFocusPainted(false);
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarReserva();
            }
        });
        panelBotones.add(btnAgregar);

        JButton btnModificar = new JButton("Modificar Reserva");
        btnModificar.setBackground(new Color(70, 130, 180));
        btnModificar.setForeground(Color.WHITE);
        btnModificar.setFocusPainted(false);
        btnModificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modificarReserva();
            }
        });
        panelBotones.add(btnModificar);

        JButton btnEliminar = new JButton("Eliminar Reserva");
        btnEliminar.setBackground(new Color(70, 130, 180));
        btnEliminar.setForeground(Color.WHITE);
        btnEliminar.setFocusPainted(false);
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarReserva();
            }
        });
        panelBotones.add(btnEliminar);

        // Botón para abrir la ventana de gestión de tours
        JButton btnGestionTours = new JButton("Gestión de Tours");
        btnGestionTours.setBackground(new Color(70, 130, 180));
        btnGestionTours.setForeground(Color.WHITE);
        btnGestionTours.setFocusPainted(false);
        btnGestionTours.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirGestionTours();
            }
        });
        panelFormulario.add(btnGestionTours, BorderLayout.EAST);
    }

    private void cargarReservas() {
        tableModel.setRowCount(0);
        ArrayList<Reserva> reservas = (ArrayList<Reserva>) controladorReserva.obtenerTodasLasReservas();
        for (Reserva reserva : reservas) {
            tableModel.addRow(new Object[]{reserva.getCodigoReserva(), reserva.getNombreHotel(), reserva.getNumPersonas(), reserva.getFechaInicio(), reserva.getFechaFin(), reserva.getCosteTotal(), reserva.getDireccion(), reserva.getCliente().getCodigo(), reserva.getCliente().getEmail()});
        }
    }

    private void abrirGestionTours() {
        TourVista tourVista = new TourVista();
        tourVista.setVisible(true);
    }

    private void modificarReserva() {
        int codigoReserva = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el código de reserva a modificar:"));

        Reserva reservaAModificar = null;
        for (Reserva reserva : controladorReserva.obtenerTodasLasReservas()) {
            if (reserva.getCodigoReserva() == codigoReserva) {
                reservaAModificar = reserva;
                break;
            }
        }

        if (reservaAModificar != null) {
            controladorReserva.modificarReserva(codigoReserva, reservaAModificar);
            JOptionPane.showMessageDialog(this, "Reserva modificada exitosamente.");
            cargarReservas();
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró ninguna reserva con el código proporcionado.");
        }
    }

    private void eliminarReserva() {
        // Obtener el código de cliente, el código de reserva y el email
        int codigoCliente = Integer.parseInt(txtCodigoCliente.getText());
        int codigoReserva = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el código de reserva:"));
        String email = txtEmail.getText();

        // Llamar al método eliminarReserva del controlador y mostrar el mensaje de confirmación
        boolean eliminado = controladorReserva.eliminarReserva(codigoCliente, codigoReserva, email);
        if (eliminado) {
            JOptionPane.showMessageDialog(this, "Reserva eliminada exitosamente.");
            cargarReservas(); // Recargar la tabla de reservas después de eliminar
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar la reserva. Verifique los datos ingresados.");
        }
    }

    private void agregarReserva() {
        // Obtener los datos ingresados por el usuario desde los campos de texto
        int codigoReserva = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el código de reserva:"));
        String nombreHotel = JOptionPane.showInputDialog("Ingrese el nombre del hotel:");
        int numPersonas = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el número de personas:"));
        String fechaInicio = JOptionPane.showInputDialog("Ingrese la fecha de inicio:");
        String fechaFin = JOptionPane.showInputDialog("Ingrese la fecha de fin:");
        double costeTotal = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el costo total:"));
        String direccion = JOptionPane.showInputDialog("Ingrese la dirección:");

        // Obtener el código de cliente como entero
        int codigoCliente = Integer.parseInt(txtCodigoCliente.getText());
        String email = txtEmail.getText();

        // Crear una instancia de Agencia si no tienes una ya
        Agencia agencia = new Agencia(); // Asegúrate de tener una instancia válida aquí

        Cliente cliente = agencia.buscarCliente(codigoCliente);
        if (cliente != null && cliente.getEmail().equals(email)) {
            Reserva nuevaReserva = new Reserva(codigoReserva, nombreHotel, numPersonas, fechaInicio, fechaFin, direccion, cliente, null, costeTotal);
            controladorReserva.agregarReserva(nuevaReserva);
            JOptionPane.showMessageDialog(this, "Reserva agregada exitosamente.");
            cargarReservas();
        } else {
            JOptionPane.showMessageDialog(this, "Cliente no encontrado o email incorrecto.");
        }
    }



}




