package worldTrip.principal;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import worldTrip.controlador.ControladorCliente;
import worldTrip.controlador.ControladorReserva;
import worldTrip.modelo.Agencia;
import worldTrip.vistas.ClienteVista;
import worldTrip.vistas.ReservaVista;

public class Menu extends JFrame {
    private static final long serialVersionUID = 1L;
    private Agencia sistema;

    public Menu() {
        sistema = new Agencia();
        initComponents();
    }

    private void initComponents() {
        setTitle("Agencia de Viajes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new BorderLayout());

        JPanel panel = new JPanel(new GridLayout(4, 1));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnGestionCliente = new JButton("Gestion de Cliente");
        btnGestionCliente.setBackground(new Color(70, 130, 180));
        btnGestionCliente.setForeground(Color.WHITE);
        btnGestionCliente.setFocusPainted(false);
        btnGestionCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	ControladorCliente controladorcliente = new ControladorCliente(sistema); // Pasar el sistema al controlador
                ClienteVista clienteVista = new ClienteVista(controladorcliente);
                clienteVista.setVisible(true);
            }
        });
        panel.add(btnGestionCliente);

       

        JButton btnGestionReservas = new JButton("Gestión de Reservas");
        btnGestionReservas.setBackground(new Color(70, 130, 180));
        btnGestionReservas.setForeground(Color.WHITE);
        btnGestionReservas.setFocusPainted(false);
        btnGestionReservas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorReserva controladorReserva = new ControladorReserva(sistema); 
                ReservaVista reservaVista = new ReservaVista(controladorReserva);
                reservaVista.setVisible(true);
            }
        });
        panel.add(btnGestionReservas);

        JButton btnSalir = new JButton("Salir");
        btnSalir.setBackground(new Color(70, 130, 180));
        btnSalir.setForeground(Color.WHITE);
        btnSalir.setFocusPainted(false);
        btnSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        panel.add(btnSalir);

        add(panel, BorderLayout.CENTER);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Menu menu = new Menu();
                menu.setVisible(true);
            }
        });
    }
    

}



