package worldTrip.modelo;

import java.util.ArrayList;

public class Agencia {
    private ArrayList<Cliente> clientes;
    private ArrayList<Reserva> reservas;
    private ArrayList<Tour> tours; // Nueva lista para almacenar tours

    public Agencia() {
        this.clientes = new ArrayList<>();
        this.reservas = new ArrayList<>();
        this.tours = new ArrayList<>();
    }

    public void altaCliente(Cliente cliente) {
        clientes.add(cliente);
        System.out.println("Cliente dado de alta exitosamente.");
    }

    public Cliente buscarCliente(int codigo) {
        for (Cliente cliente : clientes) {
            if (cliente.getCodigo() == codigo) {
                return cliente;
            }
        }
        return null;
    }

    public void realizarReserva(Cliente cliente, Reserva reserva) {
        reservas.add(reserva);
        System.out.println("Reserva realizada exitosamente para el cliente " + cliente.getNombre() + " " + cliente.getApellido() + ". Costo total: " + reserva.getCosteTotal());
    }

    public void cancelarReserva(int codigoCliente, String email) {
        Cliente cliente = buscarCliente(codigoCliente);
        if (cliente == null || !cliente.getEmail().equals(email)) {
            System.out.println("Cliente no encontrado o email incorrecto.");
            return;
        }

        for (int i = 0; i < reservas.size(); i++) {
            if (reservas.get(i).getCodigoReserva() == codigoCliente) {
                reservas.remove(i);
                System.out.println("Reserva cancelada exitosamente.");
                return;
            }
        }
        System.out.println("Reserva no encontrada.");
    }

    public Reserva buscarReserva(int codigoReserva) {
        for (Reserva reserva : reservas) {
            if (reserva.getCodigoReserva() == codigoReserva) {
                return reserva;
            }
        }
        return null;
    }

    public ArrayList<Reserva> obtenerTodasLasReservas() {
        return reservas;
    }

    public void eliminarReserva(int codigoReserva) {
        for (int i = 0; i < reservas.size(); i++) {
            if (reservas.get(i).getCodigoReserva() == codigoReserva) {
                reservas.remove(i);
                System.out.println("Reserva eliminada exitosamente.");
                return;
            }
        }
        System.out.println("Reserva no encontrada.");
    }

    // Métodos para manejar tours
    public void agregarTour(Tour tour) {
        tours.add(tour);
        System.out.println("Tour agregado exitosamente.");
    }

    public ArrayList<Tour> obtenerTodosLosTours() {
        return tours;
    }
}





