package worldTrip.modelo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Reserva {

    private static final double PRECIO_POR_DIA = 60.0;
    private static final double PRECIO_ADICIONAL_POR_PERSONA = 20.0;
    private static final double PRECIO_TOUR_FIJO = 70.0; // Precio fijo del tour

    private int codigoReserva;
    private String nombreHotel;
    private int numPersonas;
    private String fechaInicio;
    private String fechaFin;
    private double costeTotal;
    private String direccion;
    private Cliente cliente; // Nuevo campo para el cliente
    private Tour tour; // Campo existente para el tour

    public Reserva(int codigoReserva, String nombreHotel, int numPersonas, String fechaInicio, String fechaFin, String direccion, double costeTotal) {
        this.codigoReserva = codigoReserva;
        this.nombreHotel = nombreHotel;
        this.numPersonas = numPersonas;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.direccion = direccion;
        this.costeTotal = costeTotal;
        this.tour = null; // Inicialmente sin tour
    }

    public Reserva(int codigoReserva, String nombreHotel, int numPersonas, String fechaInicio, String fechaFin, String direccion, Cliente cliente, Tour tour, double costeTotal) {
        this.codigoReserva = codigoReserva;
        this.nombreHotel = nombreHotel;
        this.numPersonas = numPersonas;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.direccion = direccion;
        this.cliente = cliente;
        this.tour = tour;
        this.costeTotal = costeTotal;
    }

    private long calcularDiasEntreFechas() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date fechaInicioDate = sdf.parse(fechaInicio);
            Date fechaFinDate = sdf.parse(fechaFin);
            long diffInMillies = Math.abs(fechaFinDate.getTime() - fechaInicioDate.getTime());
            return TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private double calcularCosteTotal() {
        long dias = calcularDiasEntreFechas();
        double costePorDia = PRECIO_POR_DIA + (numPersonas - 1) * PRECIO_ADICIONAL_POR_PERSONA;
        double costeTotal = dias * costePorDia;

        if (tour != null) {
            costeTotal += PRECIO_TOUR_FIJO; // Precio fijo del tour
        }

        return costeTotal;
    }

    public int getCodigoReserva() {
        return codigoReserva;
    }

    public void setCodigoReserva(int codigoReserva) {
        this.codigoReserva = codigoReserva;
    }

    public String getNombreHotel() {
        return nombreHotel;
    }

    public void setNombreHotel(String nombreHotel) {
        this.nombreHotel = nombreHotel;
    }

    public int getNumPersonas() {
        return numPersonas;
    }

    public void setNumPersonas(int numPersonas) {
        this.numPersonas = numPersonas;
        this.costeTotal = calcularCosteTotal(); // Actualizar el coste total
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
        this.costeTotal = calcularCosteTotal(); // Actualizar el coste total
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
        this.costeTotal = calcularCosteTotal(); // Actualizar el coste total
    }

    public double getCosteTotal() {
        return costeTotal;
    }

    public void setCosteTotal(double costeTotal) {
        this.costeTotal = costeTotal;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Tour getTour() {
        return tour;
    }

    public void setTour(Tour tour) {
        this.tour = tour;
        this.costeTotal = calcularCosteTotal(); // Actualizar el coste total
    }

    @Override
    public String toString() {
        return "Reserva [codigoReserva=" + codigoReserva + ", nombreHotel=" + nombreHotel + ", numPersonas=" + numPersonas
                + ", fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin + ", costeTotal=" + costeTotal
                + ", direccion=" + direccion + ", cliente=" + cliente + ", tour=" + tour + "]";
    }
}


