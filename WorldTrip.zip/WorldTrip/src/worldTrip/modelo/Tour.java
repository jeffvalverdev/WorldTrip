package worldTrip.modelo;

public class Tour {

    private int codigoTour;
    private String nombreTour;
    private int duracion;
    private double coste;
    private String fechaInicio;
    private String fechaFin;

    public Tour(int codigoTour, String nombreTour, int duracion, double coste, String fechaInicio, String fechaFin) {
        this.codigoTour = codigoTour;
        this.nombreTour = nombreTour;
        this.duracion = duracion;
        this.coste = coste;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
    }

    public int getCodigoTour() {
        return codigoTour;
    }

    public void setCodigoTour(int codigoTour) {
        this.codigoTour = codigoTour;
    }

    public String getNombreTour() {
        return nombreTour;
    }

    public void setNombreTour(String nombreTour) {
        this.nombreTour = nombreTour;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(String fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public String getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(String fechaFin) {
        this.fechaFin = fechaFin;
    }

    public double getCoste() {
		return coste;
	}

	public void setCoste(double coste) {
		this.coste = coste;
	}

	@Override
    public String toString() {
        return "Tour [codigoTour=" + codigoTour + ", nombreTour=" + nombreTour + ", duracion=" + duracion
                + ", fechaInicio=" + fechaInicio + ", fechaFin=" + fechaFin + "]";
    }
}

