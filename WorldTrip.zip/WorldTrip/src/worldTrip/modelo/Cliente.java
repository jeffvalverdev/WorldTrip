package worldTrip.modelo;

public class Cliente {

	private static int contadorClientes = 0; 

    private int codigo;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private static boolean pago20Porciento;

    public Cliente(String nombre, String apellido, String email, String telefono) {
        this.codigo = ++contadorClientes; 
        this.apellido = apellido;
        this.email = email;
        this.telefono = telefono;
        Cliente.pago20Porciento = false;
    }

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public boolean isPago20Porciento() {
		return pago20Porciento;
	}

	public void setPago20Porciento(boolean pago20Porciento) {
		Cliente.pago20Porciento = pago20Porciento;
	}

	@Override
	public String toString() {
		return "Cliente [codigo=" + codigo + ", nombre=" + nombre + ", apellido=" + apellido + ", email=" + email
				+ ", telefono=" + telefono + ", pago20Porciento=" + pago20Porciento + ", getCodigo()=" + getCodigo()
				+ ", getNombre()=" + getNombre() + ", getApellido()=" + getApellido() + ", getEmail()=" + getEmail()
				+ ", getTelefono()=" + getTelefono() + ", isPago20Porciento()=" + isPago20Porciento() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
    
}
