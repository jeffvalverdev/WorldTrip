package worldTrip.principal;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.*;

import worldTrip.controlador.ControladorCliente;
import worldTrip.controlador.ControladorReserva;
import worldTrip.modelo.Agencia;
import worldTrip.vistas.ClienteVista;
import worldTrip.vistas.ReservaVista;

public class Menu extends JFrame {
    private static final long serialVersionUID = 1L;
    private Agencia sistema;

    public Menu() {
        sistema = new Agencia();
        initComponents();
        setLocationRelativeTo(null); 
    }

    private void initComponents() {
        setTitle("Agencia de Viajes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        
        // Crear un borde bonito alrededor de la ventana
        Border border = BorderFactory.createLineBorder(new Color(70, 130, 180), 3);
        Border emptyBorder = new EmptyBorder(20, 20, 20, 20);
        CompoundBorder compoundBorder = new CompoundBorder(border, emptyBorder);
        
        // Crear un JPanel para contener todos los componentes de la ventana y aplicarle el borde compuesto
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBorder(compoundBorder);
        setContentPane(contentPanel);

        // Panel para centrar el texto
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(Color.WHITE);
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbcCenter = new GridBagConstraints();
        gbcCenter.gridx = 0;
        gbcCenter.gridy = 0;
        gbcCenter.weightx = 1;
        gbcCenter.anchor = GridBagConstraints.CENTER;
        gbcCenter.insets = new Insets(10, 0, 10, 0);

        // Texto de bienvenida
        JLabel lblWelcome = new JLabel("¡Bienvenido a WorldTrip!", SwingConstants.CENTER);
        lblWelcome.setFont(new Font("Arial", Font.BOLD, 40));
        centerPanel.add(lblWelcome, gbcCenter);

        contentPanel.add(centerPanel, BorderLayout.NORTH);

        // Panel para los botones
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.WHITE);
        GridBagConstraints gbcPanel = new GridBagConstraints();
        gbcPanel.gridx = 0;
        gbcPanel.gridy = 0;
        gbcPanel.insets = new Insets(10, 0, 10, 0);
        gbcPanel.fill = GridBagConstraints.HORIZONTAL; // Los botones tendrán el mismo tamaño horizontalmente

        // Botón para gestionar clientes
        gbcPanel.gridy++;
        JButton btnGestionCliente = new JButton("Gestión de Clientes");
        btnGestionCliente.setBackground(new Color(70, 130, 180));
        btnGestionCliente.setForeground(Color.WHITE);
        btnGestionCliente.setFocusPainted(false);
        btnGestionCliente.setFont(new Font("Arial", Font.PLAIN, 16));
        btnGestionCliente.setPreferredSize(new Dimension(200, 40)); // Tamaño preferido de los botones
        btnGestionCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorCliente controladorcliente = new ControladorCliente(sistema); // Pasar el sistema al controlador
                ClienteVista clienteVista = new ClienteVista(controladorcliente);
                clienteVista.setVisible(true);
            }
        });
        panel.add(btnGestionCliente, gbcPanel);

        // Botón para gestionar reservas
        gbcPanel.gridy++;
        JButton btnGestionReservas = new JButton("Gestión de Reservas");
        btnGestionReservas.setBackground(new Color(70, 130, 180));
        btnGestionReservas.setForeground(Color.WHITE);
        btnGestionReservas.setFocusPainted(false);
        btnGestionReservas.setFont(new Font("Arial", Font.PLAIN, 16));
        btnGestionReservas.setPreferredSize(new Dimension(200, 40)); // Tamaño preferido de los botones
        btnGestionReservas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ControladorReserva controladorReserva = new ControladorReserva(sistema); 
                ReservaVista reservaVista = new ReservaVista(controladorReserva);
                reservaVista.setVisible(true);
            }
        });
        panel.add(btnGestionReservas, gbcPanel);

        // Botón para ver información y calificar el servicio
        gbcPanel.gridy++;
        JButton btnVerInformacion = new JButton("Ver Información");
        btnVerInformacion.setBackground(new Color(70, 130, 180));
        btnVerInformacion.setForeground(Color.WHITE);
        btnVerInformacion.setFocusPainted(false);
        btnVerInformacion.setFont(new Font("Arial", Font.PLAIN, 16));
        btnVerInformacion.setPreferredSize(new Dimension(200, 40)); // Tamaño preferido de los botones
        btnVerInformacion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame infoFrame = new JFrame("Información del Cliente");
                JPanel infoPanel = new JPanel(new GridBagLayout());
                GridBagConstraints gbcInfo = new GridBagConstraints();
                infoPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
                infoFrame.getContentPane().add(infoPanel);
                infoFrame.setSize(500, 300);
                infoFrame.setLocationRelativeTo(null);

                JLabel lblCodigo = new JLabel("Código Cliente:");
                gbcInfo.gridx = 0;
                gbcInfo.gridy = 0;
                gbcInfo.insets = new Insets(0, 0, 10, 0);
                infoPanel.add(lblCodigo, gbcInfo);
                JTextField txtCodigo = new JTextField(15);
                gbcInfo.gridx = 1;
                gbcInfo.gridy = 0;
                infoPanel.add(txtCodigo, gbcInfo);

                JLabel lblEmail = new JLabel("Email:");
                gbcInfo.gridx = 0;
                gbcInfo.gridy = 1;
                infoPanel.add(lblEmail, gbcInfo);

                JTextField txtEmail = new JTextField(15);
                gbcInfo.gridx = 1;
                gbcInfo.gridy = 1;
                infoPanel.add(txtEmail, gbcInfo);

                // Botón para obtener la información del cliente
                JButton btnObtenerInfo = new JButton("Obtener Información");
                btnObtenerInfo.setBackground(new Color(70, 130, 180));
                btnObtenerInfo.setForeground(Color.WHITE);
                gbcInfo.gridx = 0;
                gbcInfo.gridy = 2;
                gbcInfo.gridwidth = 2;
                gbcInfo.anchor = GridBagConstraints.CENTER;
                infoPanel.add(btnObtenerInfo, gbcInfo);

                // ActionListener para el botón de obtener información
                btnObtenerInfo.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        // Aquí podrías consultar la información del cliente y sus reservas
                        String codigoCliente = txtCodigo.getText();
                        String emailCliente = txtEmail.getText();

                        // Simulando la obtención de información
                        String informacionCliente = "Código Cliente: " + codigoCliente + "\n" +
                                                    "Email: " + emailCliente + "\n\n" +
                                                    "Reserva(s): \n" +
                                                    "------------------\n";
                        // Obtener información de la reserva
                        // Aquí deberías agregar la información de las reservas asociadas al cliente

                        JTextArea infoTextArea = new JTextArea(informacionCliente);
                        infoTextArea.setEditable(false);
                        JScrollPane scrollPane = new JScrollPane(infoTextArea);
                        
                        JOptionPane.showMessageDialog(null, scrollPane, "Información del Cliente", JOptionPane.PLAIN_MESSAGE);
                    }
                });

                infoFrame.setVisible(true);
            }
        });
        panel.add(btnVerInformacion, gbcPanel);
        
        
        

        // Botón para salir del programa
        gbcPanel.gridy++;
        JButton btnSalir = new JButton("Salir");
        btnSalir.setBackground(new Color(70, 130, 180));
        btnSalir.setForeground(Color.WHITE);
        btnSalir.setFocusPainted(false);
        btnSalir.setFont(new Font("Arial", Font.PLAIN, 16));
        btnSalir.setPreferredSize(new Dimension(200, 40)); // Tamaño preferido de los botones
        btnSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        panel.add(btnSalir, gbcPanel);

        // Agregar un borde decorativo al panel de botones
        TitledBorder titledBorder = BorderFactory.createTitledBorder(new LineBorder(new Color(70, 130, 180), 2), "Opciones", TitledBorder.CENTER, TitledBorder.TOP);
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 16));
        panel.setBorder(titledBorder);

        contentPanel.add(panel, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Menu menu = new Menu();
                menu.setVisible(true);
            }
        });
    }
}

                






