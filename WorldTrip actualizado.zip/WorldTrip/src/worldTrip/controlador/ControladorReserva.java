package worldTrip.controlador;

import java.util.List;

import worldTrip.modelo.Agencia;
import worldTrip.modelo.Reserva;

public class ControladorReserva {
    private List<Reserva> listaReservas;

    public ControladorReserva(Agencia sistema) {
        this.listaReservas = sistema.obtenerTodasLasReservas(); // Obtiene las reservas del sistema
    }

    public void agregarReserva(Reserva reserva) {
        listaReservas.add(reserva);
    }

    public boolean eliminarReserva(int codigoCliente, int codigoReserva, String email) {
        for (Reserva reserva : listaReservas) {
            if (reserva.getCodigoReserva() == codigoReserva && reserva.getCliente().getCodigo() == codigoCliente && reserva.getCliente().getEmail().equals(email)) {
                listaReservas.remove(reserva);
                return true; // Devuelve true si la reserva se elimina correctamente
            }
        }
        return false; // Devuelve false si no se puede eliminar la reserva
    }

    public void modificarReserva(int codigoReserva, Reserva reservaModificada) {
        for (int i = 0; i < listaReservas.size(); i++) {
            if (listaReservas.get(i).getCodigoReserva() == codigoReserva) {
                listaReservas.set(i, reservaModificada);
                break;
            }
        }
    }

    public List<Reserva> obtenerTodasLasReservas() {
        return listaReservas;
    }
}

