package worldTrip.vistas;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import worldTrip.controlador.ControladorCliente;
import worldTrip.modelo.Cliente;

public class ClienteVista extends JFrame {
    private static final long serialVersionUID = 1L;

    private ControladorCliente controladorCliente;

    private JTextField txtCodigo;
    private JTextField txtEmail;
    private JTextArea txtResultado;

    public ClienteVista(ControladorCliente controladorCliente) {
        this.controladorCliente = controladorCliente;
        initComponents();
    }

    private void initComponents() {
        setTitle("Gestión de Cliente");
        setLayout(new GridBagLayout());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        setLocationRelativeTo(null);
        JLabel lblCodigo = new JLabel("Código:");
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(lblCodigo, gbc);

        txtCodigo = new JTextField(10);
        gbc.gridx = 1;
        add(txtCodigo, gbc);

        JLabel lblEmail = new JLabel("Email:");
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(lblEmail, gbc);

        txtEmail = new JTextField(20);
        gbc.gridx = 1;
        add(txtEmail, gbc);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setBackground(new Color(70, 130, 180));
        btnBuscar.setForeground(Color.WHITE);
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarCliente();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(btnBuscar, gbc);

        // Resultado
        txtResultado = new JTextArea(10, 5);
        txtResultado.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(txtResultado);
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        add(scrollPane, gbc);

        // Botón "Crear Cliente"
        JButton btnCrearCliente = new JButton("Crear Cliente");
        btnCrearCliente.setBackground(new Color(70, 130, 180));
        btnCrearCliente.setForeground(Color.WHITE);
        btnCrearCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                abrirVentanaCrearCliente();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        add(btnCrearCliente, gbc);
        
    }

    
	private void buscarCliente() {
        try {
            // Guardar datos ingresados en variables temporales
            String codigoTemporal = txtCodigo.getText();
            String emailTemporal = txtEmail.getText();

            int codigo = Integer.parseInt(codigoTemporal);
            String email = emailTemporal;

            // Verificar si el cliente ya está agregado
            Cliente clienteExistente = controladorCliente.buscarCliente(codigo, email);
            if (clienteExistente != null) {
                txtResultado.setText("¡Cliente ya agregado!");
            } else {
                txtResultado.setText("Cliente no encontrado.");
            }

            // Restaurar datos temporales a los campos de texto
            txtCodigo.setText(codigoTemporal);
            txtEmail.setText(emailTemporal);
        } catch (NumberFormatException e) {
            txtResultado.setText("El código debe ser un número.");
        }
    }

    private void abrirVentanaCrearCliente() {
        JFrame frameCrearCliente = new JFrame("Crear Cliente");
        frameCrearCliente.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblNombre = new JLabel("Nombre:");
        gbc.gridx = 0;
        gbc.gridy = 0; // Fila 0
        frameCrearCliente.add(lblNombre, gbc);

        JTextField txtNombre = new JTextField(20); // Aumentar el tamaño del JTextField
        gbc.gridx = 1;
        gbc.gridwidth = 2; // Ocupar más columnas
        frameCrearCliente.add(txtNombre, gbc);

        JLabel lblApellido = new JLabel("Apellido:");
        gbc.gridx = 0;
        gbc.gridy = 1; // Fila 1
        gbc.gridwidth = 1; // Restaurar el valor por defecto
        frameCrearCliente.add(lblApellido, gbc);

        JTextField txtApellido = new JTextField(20); // Aumentar el tamaño del JTextField
        gbc.gridx = 1;
        gbc.gridwidth = 2; // Ocupar más columnas
        frameCrearCliente.add(txtApellido, gbc);

        JLabel lblEmail = new JLabel("Email:");
        gbc.gridx = 0;
        gbc.gridy = 2; // Fila 2
        gbc.gridwidth = 1; // Restaurar el valor por defecto
        frameCrearCliente.add(lblEmail, gbc);

        JTextField txtEmail = new JTextField(20); // Aumentar el tamaño del JTextField
        gbc.gridx = 1;
        gbc.gridwidth = 2; // Ocupar más columnas
        frameCrearCliente.add(txtEmail, gbc);

        JLabel lblTelefono = new JLabel("Teléfono:");
        gbc.gridx = 0;
        gbc.gridy = 3; // Fila 3
        gbc.gridwidth = 1; // Restaurar el valor por defecto
        frameCrearCliente.add(lblTelefono, gbc);

        JTextField txtTelefono = new JTextField(20); // Aumentar el tamaño del JTextField
        gbc.gridx = 1;
        gbc.gridwidth = 2; // Ocupar más columnas
        frameCrearCliente.add(txtTelefono, gbc);
        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.setBackground(new Color(70, 130, 180));
        btnGuardar.setForeground(Color.WHITE);
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = txtNombre.getText();
                String apellido = txtApellido.getText();
                String email = txtEmail.getText();
                String telefono = txtTelefono.getText();

                Cliente cliente = controladorCliente.crearCliente(nombre, apellido, email, telefono);

                // Mostrar el código del cliente en un nuevo diálogo
                JOptionPane.showMessageDialog(frameCrearCliente, "Cliente creado exitosamente. Código del cliente: " + cliente.getCodigo(), "Cliente Creado", JOptionPane.INFORMATION_MESSAGE);

                frameCrearCliente.dispose();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 4; // Fila 4
        gbc.gridwidth = 2;
        frameCrearCliente.add(btnGuardar, gbc);

        frameCrearCliente.pack();
        frameCrearCliente.setLocationRelativeTo(null);
        frameCrearCliente.setVisible(true);
    }

}

    
